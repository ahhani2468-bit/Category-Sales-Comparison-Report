# -*- coding: utf-8 -*-
{
    'name': 'Category Sales Comparison Report',
    'version': '18.0.1.0.0',
    'category': 'Sales/Reporting',
    'summary': 'Compare sales between product categories with unit conversion',
    'description': """
        Wizard to compare sales quantities between product categories for a date range.
        - Select date range and up to multiple categories
        - Shows products per category with quantities sold
        - Converts larger UoM to smaller UoM automatically
        - Side-by-side PDF comparison report
    """,
    'author': 'Flexe',
    'depends': ['sale_management', 'uom', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/category_comparison_wizard_view.xml',
        'report/category_comparison_report.xml',
        'report/category_comparison_report_template.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'OPL-1',
    'currency': 'EUR',
    'price': '10.0',

}
