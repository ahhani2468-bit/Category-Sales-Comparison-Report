# -*- coding: utf-8 -*-
from odoo import models, fields, api


class CategoryComparisonWizard(models.TransientModel):
    _name = 'category.comparison.wizard'
    _description = 'Category Sales Comparison Wizard'

    date_from = fields.Date(string="من تاريخ", required=True)
    date_to = fields.Date(string="إلى تاريخ", required=True)
    category_ids = fields.Many2many('product.category', string="الفئات المختارة", required=True)

    def action_print_report(self):
        self.ensure_one()
        # جلب البيانات المنظمة للفئات والمنتجات
        categories_data = self._get_comparison_data()

        # تجهيز قاموس البيانات لإرساله لقالب الـ PDF
        data = {
            'form': {
                'date_from': self.date_from,
                'date_to': self.date_to,
            },
            'categories_data': categories_data
        }
        # استدعاء أكشن التقرير مع تمرير البيانات
        return self.env.ref('category_comparison_report.action_report_category_comparison').report_action(self,
                                                                                                          data=data)

    def _get_comparison_data(self):
        result = []
        for cat in self.category_ids:
            # البحث عن بنود المبيعات المؤكدة لهذه الفئة في الفترة المحددة
            order_lines = self.env['sale.order.line'].search([
                ('state', 'in', ['sale', 'done']),
                ('order_id.date_order', '>=', self.date_from),
                ('order_id.date_order', '<=', self.date_to),
                ('product_id.categ_id', '=', cat.id)
            ])

            products_qty = {}
            total_cat_qty = 0

            for line in order_lines:
                # تحويل الكمية للوحدة الصغرى (Reference UoM) المخزنة في سجل المنتج
                # دالة _compute_quantity تتعامل مع معاملات التحويل تلقائياً
                uom_qty = line.product_uom._compute_quantity(line.product_uom_qty, line.product_id.uom_id)

                prod_name = line.product_id.name
                if prod_name in products_qty:
                    products_qty[prod_name] += uom_qty
                else:
                    products_qty[prod_name] = uom_qty
                total_cat_qty += uom_qty

            result.append({
                'name': cat.name,
                'products': [{'name': k, 'qty': v} for k, v in products_qty.items()],
                'total_qty': total_cat_qty
            })
        return result


class CategoryComparisonReportAbstract(models.AbstractModel):
    # الاسم التقني يجب أن يكون report. + (اسم الموديول) + . + (اسم قالب الـ XML)
    _name = 'report.category_comparison_report.report_comparison_document'
    _description = 'Logic for Category Comparison PDF'

    @api.model
    def _get_report_values(self, docids, data=None):
        # في حال تم استدعاء التقرير بدون data (مباشرة)، نأخذ السجلات من docids
        if not data:
            data = {}

        return {
            'doc_ids': docids,
            'doc_model': 'category.comparison.wizard',
            'data': data,
        }